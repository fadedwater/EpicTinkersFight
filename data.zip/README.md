为史诗战斗添加了对匠魂3及一些附属以及mvw的兼容性。

主要为作者自己的水槽包服务，因此并没有添加全新的动作，基本只是对原版史诗战斗动作的复用。

Added compatibility for Tinkers' Construct 3 and its attachments as well as MVW for Epic Fight.  

Mainly serves the author's own pack, so no new actions have been added, and it is basically a reuse of the original epic combat action.
